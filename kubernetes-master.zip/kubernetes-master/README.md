# kubernetes
Examples of deployments, pods, configmap, autoscaling
